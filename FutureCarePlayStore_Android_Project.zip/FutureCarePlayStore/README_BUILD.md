# FutureCare Memorial Plan — Android / Google Play project

This project packages the existing FutureCare portal HTML as an Android WebView app.

## Source used
`app/src/main/assets/index.html` is copied from:
`FutureCare_SUPPORT_AGENT_RECEIVE_FIXED.html`

The portal HTML was not rewritten as part of this packaging step.

## Build
Open this folder in Android Studio, allow Gradle to sync, then:

- Build > Build APK(s) for a test APK
- Build > Generate Signed Bundle / APK
- Choose **Android App Bundle (AAB)** for Google Play
- Create/use a release keystore and keep the keystore/password safe.

## Important before Play Store submission
1. Test Owner, Agent, and Member login on a real Android device.
2. Test Supabase connectivity and all portal sections.
3. Confirm the production Supabase URL/key and RLS policies.
4. Add a production app icon and Play Store screenshots.
5. Prepare a privacy policy and complete Google Play Data Safety declarations.
6. Verify the current Google Play target-SDK requirement before release.
7. Do not publish until Support/Messages behavior is verified in the actual production build.
